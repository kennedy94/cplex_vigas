#include "gecode.h"

int main(int argc, char *argv[]){

	char *inst;
	if(argc < 2)
		inst = "problema.txt";
	else{
		if(argc < 3)
			inst = argv[1];
		else{
			cout << "Argumentos demais" << endl;
			exit(0);
		}
		
		
	}

	//GECODE

	Problem *modelo = new Problem(inst);
	//modelo->imprimir_vetor_testes();
	DFS<Problem> search(modelo);
	
	ofstream arq;
	char xu[100];
	strcpy(xu, inst);
	strcat(xu, ".pat");

	arq.open("aux", ofstream::out);

	int contador = 0;
	Problem *sol;

	bool teste = false;

	
	//arq << "substitue" << endl;

	arq << 0 << " ";
	for(int i = 0; i < modelo->Viga[0].k; i++)
		arq << 0 << " ";
	arq << endl;

	while ((sol = search.next())) {
		//sol->imprimir();
		sol->imprimir_solu(arq);
		arq << endl;
		++ contador;
		delete sol;    
	}
	delete modelo;
	arq.close();
	


	ifstream input("aux", ifstream::in);

	arq.open(xu, ofstream::out);

	string ch;
	arq << contador+1 << endl;
	while (getline(input,ch))
		arq << ch << endl;
	

	input.close();
	arq.close();
	remove( "aux" );
	cout << "Padroes gerados com sucesso!" << endl;
	
    return 0;
}
